# CloudGuard Pre-Storage DLP Engine: Quantitative Evaluation

**Test Dataset Size**: 25 synthetic files across 5 file formats (`.txt`, `.csv`, `.pdf`, `.docx`, `.xlsx`)
**Overall Classification Accuracy**: 100.00% | **Policy Routing Accuracy**: 100.00%

### 1. Overall Binary DLP Performance (Sensitive vs Safe Payload)
| Metric | Formula | Value | Percentage | Description |
| :--- | :--- | :---: | :---: | :--- |
| **True Positives (TP)** | Correctly identified sensitive files | 18 | — | Sensitive files intercepted before storage |
| **True Negatives (TN)** | Correctly identified safe files | 7 | — | Safe business files routed directly to Safe S3 |
| **False Positives (FP)** | Safe files flagged as sensitive | 0 | — | False alarms blocking legitimate productivity |
| **False Negatives (FN)** | Sensitive files missed by DLP | 0 | — | Catastrophic data leaks into storage |
| **Precision** | $\frac{TP}{TP + FP}$ | **1.0000** | **100.0%** | Ratio of true detections over all alarms |
| **Recall (Sensitivity)** | $\frac{TP}{TP + FN}$ | **1.0000** | **100.0%** | Coverage: 100% means zero missed leaks |
| **False Positive Rate (FPR)** | $\frac{FP}{FP + TN}$ | **0.0000** | **0.0%** | Rate of benign files incorrectly flagged |
| **F1-Score** | $2 \cdot \frac{P \cdot R}{P + R}$ | **1.0000** | **100.0%** | Harmonic balance between precision and recall |

### 2. Granular Per-Data-Type Detection Breakdown
| Sensitive Entity Type | Validation Technique | Ground Truth Count | TP | FP | FN | Precision | Recall | FPR |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| `EMAIL` | RFC Linear Regex | 5 | 5 | 0 | 0 | 100.0% | 100.0% | 0.0% |
| `PHONE` | E.164 + Indian Mobile Regex | 5 | 5 | 0 | 0 | 100.0% | 100.0% | 0.0% |
| `PAN` | Entity Code Regex (4th char) | 4 | 4 | 0 | 0 | 100.0% | 100.0% | 0.0% |
| `AADHAAR` | Verhoeff Checksum Matrix | 2 | 2 | 0 | 0 | 100.0% | 100.0% | 0.0% |
| `CREDIT_CARD` | Luhn Mod-10 Checksum | 3 | 3 | 0 | 0 | 100.0% | 100.0% | 0.0% |
| `API_KEY` | High Entropy / Prefix Match | 3 | 3 | 0 | 0 | 100.0% | 100.0% | 0.0% |
| `AWS_KEY` | AKIA/ASIA Prefix + Secret Regex | 3 | 3 | 0 | 0 | 100.0% | 100.0% | 0.0% |
| `PASSWORD` | Config & Key-Value Patterns | 3 | 2 | 0 | 1 | 100.0% | 66.7% | 0.0% |

### 3. File-by-File Evaluation Audit Log
| File | Format | Expected | Detected | Expected Action | Executed Action | Match | Latency |
| :--- | :---: | :--- | :--- | :---: | :---: | :---: | :---: |
| `eval_01_safe_memo.txt` | text | None (Safe) | None (Safe) | ALLOW | ALLOW | PASS | 0.13 ms |
| `eval_02_safe_readme.md` | text | None (Safe) | None (Safe) | ALLOW | ALLOW | PASS | 0.06 ms |
| `eval_03_safe_config.json` | text | None (Safe) | None (Safe) | ALLOW | ALLOW | PASS | 0.06 ms |
| `eval_04_safe_catalog.csv` | csv | None (Safe) | None (Safe) | ALLOW | ALLOW | PASS | 0.07 ms |
| `eval_05_safe_press_release.txt` | text | None (Safe) | None (Safe) | ALLOW | ALLOW | PASS | 0.05 ms |
| `eval_06_safe_license.txt` | text | None (Safe) | None (Safe) | ALLOW | ALLOW | PASS | 0.06 ms |
| `eval_07_safe_changelog.txt` | text | None (Safe) | None (Safe) | ALLOW | ALLOW | PASS | 0.05 ms |
| `eval_08_email_directory.txt` | text | EMAIL | EMAIL | MASK | MASK | PASS | 0.09 ms |
| `eval_09_phone_roster.txt` | text | PHONE | PHONE | MASK | MASK | PASS | 0.1 ms |
| `eval_10_mixed_pii_contacts.csv` | csv | PHONE, EMAIL | PHONE, EMAIL | MASK | MASK | PASS | 0.08 ms |
| `eval_11_support_inquiry.txt` | text | PHONE, EMAIL | PHONE, EMAIL | MASK | MASK | PASS | 0.07 ms |
| `eval_12_newsletter_subscribers.txt` | text | EMAIL | EMAIL | MASK | MASK | PASS | 0.06 ms |
| `eval_13_pan_records.csv` | csv | PAN | PAN | QUARANTINE | QUARANTINE | PASS | 0.07 ms |
| `eval_14_credit_cards.csv` | csv | CREDIT_CARD | CREDIT_CARD | QUARANTINE | QUARANTINE | PASS | 0.1 ms |
| `eval_15_aadhaar_registry.txt` | text | AADHAAR | AADHAAR | QUARANTINE | QUARANTINE | PASS | 0.07 ms |
| `eval_16_pan_and_cards.csv` | csv | PAN, PHONE, CREDIT_CARD | PAN, PHONE, CREDIT_CARD | QUARANTINE | QUARANTINE | PASS | 0.09 ms |
| `eval_17_tax_filing_summary.txt` | text | PAN, AADHAAR, CREDIT_CARD | PAN, AADHAAR, CREDIT_CARD | QUARANTINE | QUARANTINE | PASS | 0.08 ms |
| `eval_18_aws_credentials.env` | text | AWS_KEY | AWS_KEY | BLOCK | BLOCK | PASS | 0.06 ms |
| `eval_19_stripe_secrets.txt` | text | API_KEY | API_KEY | BLOCK | BLOCK | PASS | 0.06 ms |
| `eval_20_github_tokens.txt` | text | API_KEY | API_KEY | BLOCK | BLOCK | PASS | 0.06 ms |
| `eval_21_database_passwords.env` | text | PASSWORD | PASSWORD | BLOCK | BLOCK | PASS | 0.06 ms |
| `eval_22_mixed_cloud_keys.txt` | text | PASSWORD, AWS_KEY, API_KEY | PASSWORD, AWS_KEY, API_KEY | BLOCK | BLOCK | PASS | 0.07 ms |
| `eval_23_employee_onboarding.docx` | docx | PHONE, EMAIL | PHONE, EMAIL | MASK | MASK | PASS | 128.92 ms |
| `eval_24_financial_audit.xlsx` | xlsx | PAN | PAN | QUARANTINE | QUARANTINE | PASS | 409.77 ms |
| `eval_25_executive_memo.pdf` | pdf | AWS_KEY, PASSWORD | AWS_KEY | BLOCK | BLOCK | PASS | 80.4 ms |